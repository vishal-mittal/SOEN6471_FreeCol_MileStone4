package net.sf.freecol.common.io.sza;

/**
 * An event created by an animation.
 */
public interface AnimationEvent {

}
